#ifndef drop_payload_h
#define drop_payload_h

void drop_payload();

#endif
