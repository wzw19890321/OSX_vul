#!/bin/bash
DYLD_INSERT_LIBRARIES=`pwd`/xpc_dict_injector.dylib /Applications/Safari.app/Contents/MacOS/Safari
#DYLD_INSERT_LIBRARIES=`pwd`/xpc_dict_injector.dylib /Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome
