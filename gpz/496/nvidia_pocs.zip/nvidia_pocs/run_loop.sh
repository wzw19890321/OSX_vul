#! /bin/bash
while true; do DYLD_INSERT_LIBRARIES=./token_template.dylib /Applications/Google\ Chrome\ Canary.app/Contents/MacOS/Google\ Chrome\ Canary --single-process --force_discrete_gpu "http://www.coffeevortex.net"; done
